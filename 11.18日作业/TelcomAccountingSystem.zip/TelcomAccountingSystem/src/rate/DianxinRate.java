package rate;

public class DianxinRate implements Rate{

	@Override
	public double getRatio() {
		// TODO Auto-generated method stub
		return (double) 0.22;
	}
	 public String toString() {
	    	return "���Ź�˾";
	    }
}
