package rate;

public class LiantongRate implements Rate{

	@Override
	public double getRatio() {
		// TODO Auto-generated method stub
		return (double) 0.30;
	}
	 public String toString() {
	    	return "��ͨ��˾";
	    }
}
