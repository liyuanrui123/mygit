package rate;

public class YidongRate implements Rate{

	@Override
	public double getRatio() {
		// TODO Auto-generated method stub
		return (double) 0.20;
	}
	 public String toString() {
	    	return "�ƶ���˾";
	    }
}
