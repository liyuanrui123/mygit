package rate;

public interface Rate {
     double getRatio();
}
