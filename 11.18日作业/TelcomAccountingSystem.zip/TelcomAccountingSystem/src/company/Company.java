package company;
import rate.*;
public interface Company {
     public Rate producerate();
}
